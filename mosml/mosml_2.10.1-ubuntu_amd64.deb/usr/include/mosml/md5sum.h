#ifdef __md5sum__
#define __md5sum__

EXTERN value md5sum(value str);

#endif
